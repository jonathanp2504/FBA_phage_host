# ============================================================
#  MODEL 1 — KINETIEKONDERZOEK
#  Doel: validatie van infectiekinetiek, GEEN Benzonase productie
#  Drie experimenten:
#    1. Één-stap groeicurve validatie (latente periode, burst size)
#    2. MOI-sweep: lysis vs lysogenie als functie van MOI
#    3. Vergelijking met Model 2 (two-step) bij zelfde parameters
# ============================================================

using Plots
using UnPack
using COBREXA
using AbstractFBCModels
using DelayDiffEq
using OrdinaryDiffEq
using SciMLBase
import SBMLFBCModels

include("./Bin/parameters.jl")
include("./Bin/FBA.jl")
include("./Bin/dFBA.jl")

model_path = joinpath(@__DIR__, "iJO1366.xml")
@assert isfile(model_path) "iJO1366.xml does not exist at path: $model_path"
model = loadFBAmodel(model_path)

# ============================================================
#  Basisparameters (zelfde als productiemodel maar f_prod=0)
# ============================================================
alpha_syn      = 2.0
beta_deg       = 0.5
K_s            = [0.0278, 0.0146, 0.0543, 0.0833]
tau            = 1.0
b              = 170.0
alfa_ads       = 1e-10
E_coli_cellDW  = 2.8e-13
p_pref         = [0.8925, 0.08925, 0.008925, 0.008925]
V_max          = [12.7, 3.75, 0.0, 4.0]
exchange_ids   = ["R_EX_glc__D_e", "R_EX_malt_e", "R_EX_glyc_e", "R_EX_ac_e"]
essentials_ids = ["R_EX_o2_e", "R_EX_nh4_e", "R_EX_pi_e", "R_EX_so4_e",
                  "R_EX_k_e", "R_EX_mg2_e", "R_EX_ca2_e", "R_EX_cl_e",
                  "R_EX_fe2_e", "R_EX_fe3_e", "R_EX_mn2_e", "R_EX_zn2_e",
                  "R_EX_cu2_e", "R_EX_cobalt2_e", "R_EX_mobd_e", "R_EX_thi_e",
                  "R_EX_ni2_e", "R_EX_sel_e", "R_EX_slnt_e", "R_EX_tungs_e"]
all_ex_ids     = [id for id in keys(model.reactions) if startswith(id, "R_EX_")]
MW_values      = [180.16, 342.3, 92.09, 60.05]
h_release      = 5.66e-12
duration       = 15.0
mu_max_vector  = [1.33, 1.26, 1.10, 0.29]
e_max_vector   = (alpha_syn .+ 0.001) ./ (beta_deg .+ mu_max_vector)
fbaCache       = buildFbaCache(model, exchange_ids, "R_BIOMASS_Ec_iJO1366_core_53p95M")

function make_params(startingBiomass, infection_time, moi)
    return Parameters(
        duration, startingBiomass,
        alpha_syn, beta_deg, K_s, V_max, p_pref,
        tau, b, alfa_ads, E_coli_cellDW, MW_values, h_release,
        "R_BIOMASS_Ec_iJO1366_core_53p95M", exchange_ids, all_ex_ids, essentials_ids,
        fbaCache,
        0.0, zeros(4),
        infection_time,
        moi * startingBiomass,
        "R_BENZ_prod",
        0.0,    # k_tox: uitgeschakeld voor kinetiekonderzoek
        0.0,    # beta_benz
        0.0,    # q_benz
        mu_max_vector, e_max_vector,
        0.0,    # f_prod = 0: geen Benzonase productie
        0.0     # Y_benz = 0: geen Benzonase yield
    )
end

# ============================================================
#  EXPERIMENT 1: Één-stap groeicurve validatie
#  Referentiewaarden: tau=1h, b=170, alfa_ads=1e-10 L/cel/h
#  Beginwaarden: N0=1e9 cel/L, MOI=0.001 (lage MOI -> lytisch)
# ============================================================
println("=== Experiment 1: Één-stap groeicurve validatie ===")

p_val = make_params(1e9, 2.0, 0.001)
sol_val = run(p_val)

t_vals = sol_val.t
S_vals = [sol_val.u[i][Sind_S]  for i in eachindex(sol_val.u)]
I_vals = [sol_val.u[i][Sind_I]  for i in eachindex(sol_val.u)]
L_vals = [sol_val.u[i][Sind_L]  for i in eachindex(sol_val.u)]
P_vals = [sol_val.u[i][Pfind]   for i in eachindex(sol_val.u)]
X_tot  = S_vals .+ I_vals .+ L_vals

# Bereken lysis-tijdstip (moment van maximum lytische cellen)
max_I_idx = argmax(I_vals)
t_lysis   = t_vals[max_I_idx]
println("  Geschatte lysis-piek bij t = $(round(t_lysis, digits=2)) uur (verwacht: ~$(2.0 + tau) uur)")

# Bereken geobserveerde burst size: ΔP / max(I) na lysis
P_before = P_vals[max_I_idx]
P_after  = maximum(P_vals[max_I_idx:end])
b_obs    = I_vals[max_I_idx] > 0 ? (P_after - P_before) / I_vals[max_I_idx] : 0.0
println("  Ingestelde burst size b = $b")
println("  Ingestelde latente periode tau = $tau uur")
println("  Adsorptieconstante alfa_ads = $alfa_ads L/cel/h")

p1_val = plot(t_vals, [S_vals I_vals L_vals X_tot],
    label=["Vatbaar (S)" "Lytisch (I)" "Lysogeen (L)" "Totaal"],
    title="Exp 1: Populatiedynamica (MOI=0.001)",
    xlabel="t [h]", ylabel="cellen/L",
    lw=2, yscale=:log10, ylims=(1, :auto),
    color=[:blue :red :green :black])

p2_val = plot(t_vals, P_vals,
    label="Vrije fagen", color=:red, lw=2,
    title="Exp 1: Faagpopulatie",
    xlabel="t [h]", ylabel="fagen/L",
    yscale=:log10, ylims=(1, :auto))

plot(p1_val, p2_val, layout=(1,2), size=(900,400))
savefig("kinetics_exp1_validation.png")
println("  Plot opgeslagen: kinetics_exp1_validation.png")

# ============================================================
#  EXPERIMENT 2: MOI-sweep
#  Doel: lysis-lysogenie beslissing als functie van MOI
#  Verwachting: bij lage MOI domineert lysis, bij hoge MOI lysogenie
# ============================================================
println("\n=== Experiment 2: MOI-sweep ===")

moi_sweep = [0.0001, 0.001, 0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
N0        = 1e9
t_inf_sw  = 2.0
frac_lys  = zeros(length(moi_sweep))
frac_lyt  = zeros(length(moi_sweep))
final_P   = zeros(length(moi_sweep))
final_B   = zeros(length(moi_sweep))   # altijd 0 want f_prod=0, voor consistentie

for (idx, moi) in enumerate(moi_sweep)
    p_sw  = make_params(N0, t_inf_sw, moi)
    sol_sw = run(p_sw)
    if SciMLBase.successful_retcode(sol_sw)
        S_f = sol_sw.u[end][Sind_S]
        I_f = sol_sw.u[end][Sind_I]
        L_f = sol_sw.u[end][Sind_L]
        X_f = S_f + I_f + L_f
        P_f = sol_sw.u[end][Pfind]
        infected_f = I_f + L_f
        frac_lys[idx] = infected_f > 0 ? L_f / infected_f : 0.0
        frac_lyt[idx] = infected_f > 0 ? I_f / infected_f : 0.0
        final_P[idx]  = P_f
        println("  MOI=$(moi): frac_lysogeen=$(round(frac_lys[idx], digits=3)) | frac_lytisch=$(round(frac_lyt[idx], digits=3)) | P=$(round(P_f, sigdigits=2))")
    else
        println("  MOI=$(moi): simulatie gefaald")
    end
end

p3_moi = plot(moi_sweep, [frac_lys frac_lyt],
    label=["Fractie lysogeen" "Fractie lytisch"],
    title="Exp 2: Lysis-Lysogenie beslissing vs MOI",
    xlabel="MOI", ylabel="Fractie geïnfecteerde cellen",
    xscale=:log10, lw=2, marker=:circle,
    color=[:green :red], ylims=(0, 1.05))

p4_moi = plot(moi_sweep, final_P,
    label="Vrije fagen (eindwaarde)",
    title="Exp 2: Eindconcentratie fagen vs MOI",
    xlabel="MOI", ylabel="fagen/L",
    xscale=:log10, yscale=:log10,
    lw=2, marker=:circle, color=:red)

plot(p3_moi, p4_moi, layout=(1,2), size=(900,400))
savefig("kinetics_exp2_moi_sweep.png")
println("  Plot opgeslagen: kinetics_exp2_moi_sweep.png")

# ============================================================
#  EXPERIMENT 3: Gevoeligheidsanalyse infectietijdstip
#  Doel: effect van t_inf op de infectiegolf
#  Vaste MOI=0.001 (lytisch regime), variabele t_inf
# ============================================================
println("\n=== Experiment 3: Effect infectietijdstip ===")

t_inf_sweep  = [0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0]
max_P_values = zeros(length(t_inf_sweep))
max_I_values = zeros(length(t_inf_sweep))

for (idx, t_inf) in enumerate(t_inf_sweep)
    p_ti  = make_params(1e9, t_inf, 0.001)
    sol_ti = run(p_ti)
    if SciMLBase.successful_retcode(sol_ti)
        max_P_values[idx] = maximum([sol_ti.u[i][Pfind]  for i in eachindex(sol_ti.u)])
        max_I_values[idx] = maximum([sol_ti.u[i][Sind_I] for i in eachindex(sol_ti.u)])
        println("  t_inf=$(t_inf)h: max fagen=$(round(max_P_values[idx], sigdigits=2)) | max lytisch=$(round(max_I_values[idx], sigdigits=2))")
    end
end

p5_tinf = plot(t_inf_sweep, max_P_values,
    label="Max vrije fagen", marker=:circle, lw=2, color=:red,
    title="Exp 3: Effect infectietijdstip (MOI=0.001)",
    xlabel="t_inf [h]", ylabel="Maximale faagconcentratie [/L]")

p6_tinf = plot(t_inf_sweep, max_I_values,
    label="Max lytische cellen", marker=:square, lw=2, color=:orange,
    title="Exp 3: Max lytische cellen vs infectietijdstip",
    xlabel="t_inf [h]", ylabel="Max lytische cellen [/L]")

plot(p5_tinf, p6_tinf, layout=(1,2), size=(900,400))
savefig("kinetics_exp3_tinf.png")
println("  Plot opgeslagen: kinetics_exp3_tinf.png")

println("\n=== Kinetiekonderzoek Model 1 voltooid ===")
